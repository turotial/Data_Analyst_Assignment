minutes = int(input("Enter minutes:112"))


hours = minutes // 60
remaining = minutes % 60

print(f"{hours} hrs {remaining} minutes")