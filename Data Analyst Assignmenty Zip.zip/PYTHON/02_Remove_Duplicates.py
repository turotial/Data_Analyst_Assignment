"""
Remove Duplicates - Remove duplicate records from data
"""
import csv
from collections import OrderedDict

def remove_duplicates_from_list(data_list, key=None):
    """Remove duplicate items from a list"""
    if key is None:
        return list(dict.fromkeys(data_list))
    else:
        seen = set()
        result = []
        for item in data_list:
            value = item[key] if isinstance(item, dict) else item[key]
            if value not in seen:
                seen.add(value)
                result.append(item)
        return result

def remove_duplicates_from_csv(input_file, output_file, key_column=None):
    """Remove duplicate rows from a CSV file"""
    rows = []
    with open(input_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        for row in reader:
            rows.append(row)
    
    if key_column:
        seen = set()
        unique_rows = []
        for row in rows:
            key_value = row.get(key_column)
            if key_value not in seen:
                seen.add(key_value)
                unique_rows.append(row)
    else:
        unique_rows = []
        seen = set()
        for row in rows:
            row_tuple = tuple(sorted(row.items()))
            if row_tuple not in seen:
                seen.add(row_tuple)
                unique_rows.append(row)
    
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(unique_rows)
    
    return len(rows), len(unique_rows)

def remove_duplicates_from_dict_list(data_list, key_fields):
    """Remove duplicate dictionaries based on specified key fields"""
    seen = set()
    result = []
    for item in data_list:
        key_tuple = tuple(item.get(field) for field in key_fields)
        if key_tuple not in seen:
            seen.add(key_tuple)
            result.append(item)
    return result

if __name__ == "__main__":
    # Example usage
    print("Remove Duplicates Examples:")
    
    # Example 1: Simple list
    numbers = [1, 2, 2, 3, 3, 3, 4, 5, 5]
    print(f"\nOriginal list: {numbers}")
    print(f"After removing duplicates: {remove_duplicates_from_list(numbers)}")
    
    # Example 2: List of dictionaries
    tickets = [
        {'id': 1, 'summary': 'Login issue', 'agent': 'Alice'},
        {'id': 2, 'summary': 'Payment failure', 'agent': 'Bob'},
        {'id': 1, 'summary': 'Login issue', 'agent': 'Alice'},
        {'id': 3, 'summary': 'Password reset', 'agent': 'Charlie'},
        {'id': 2, 'summary': 'Payment failure', 'agent': 'Bob'},
    ]
    print(f"\nOriginal tickets: {tickets}")
    unique_tickets = remove_duplicates_from_dict_list(tickets, ['id', 'summary'])
    print(f"After removing duplicates: {unique_tickets}")
    print(f"Removed {len(tickets) - len(unique_tickets)} duplicate records")
