[9:33 PM, 4/8/2026] ✨Dhanush ❤️‍🔥: SELECT sales_channel, SUM(amount) AS revenue
FROM clinic_sales
WHERE YEAR(datetime) = 2021
GROUP BY sales_channel;
[9:33 PM, 4/8/2026] ✨Dhanush ❤️‍🔥: SELECT uid, SUM(amount) AS total_spent
FROM clinic_sales
WHERE YEAR(datetime) = 2021
GROUP BY uid
ORDER BY total_spent DESC
LIMIT 10;
[9:33 PM, 4/8/2026] ✨Dhanush ❤️‍🔥: SELECT 
  MONTH(cs.datetime) AS month,
  SUM(cs.amount) AS revenue,
  SUM(e.amount) AS expense,
  SUM(cs.amount) - SUM(e.amount) AS profit,
  CASE 
    WHEN SUM(cs.amount) - SUM(e.amount) > 0 THEN 'Profitable'
    ELSE 'Not Profitable'
  END AS status
FROM clinic_sales cs
JOIN expenses e ON cs.cid = e.cid
GROUP BY MONTH(cs.datetime);