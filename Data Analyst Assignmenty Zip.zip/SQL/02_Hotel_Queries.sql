SELECT b.user_id, b.room_no
FROM bookings b
JOIN (
  SELECT user_id, MAX(booking_date) AS last_date
  FROM bookings
  GROUP BY user_id
) t
ON b.user_id = t.user_id AND b.booking_date = t.last_date;
[9:31 PM, 4/8/2026] ✨Dhanush ❤️‍🔥: SELECT bc.booking_id,
SUM(bc.item_quantity * i.item_rate) AS total_amount
FROM booking_commercials bc
JOIN items i ON bc.item_id = i.item_id
JOIN bookings b ON bc.booking_id = b.booking_id
WHERE MONTH(b.booking_date) = 11 AND YEAR(b.booking_date) = 2021
GROUP BY bc.booking_id;
[9:31 PM, 4/8/2026] ✨Dhanush ❤️‍🔥: SELECT bc.bill_id,
SUM(bc.item_quantity * i.item_rate) AS bill_amount
FROM booking_commercials bc
JOIN items i ON bc.item_id = i.item_id
WHERE MONTH(bc.bill_date) = 10 AND YEAR(bc.bill_date) = 2021
GROUP BY bc.bill_id
HAVING bill_amount > 1000;
[9:31 PM, 4/8/2026] ✨Dhanush ❤️‍🔥: WITH item_counts AS (
  SELECT 
    MONTH(bc.bill_date) AS month,
    bc.item_id,
    SUM(bc.item_quantity) AS total_qty,
    RANK() OVER (PARTITION BY MONTH(bc.bill_date) ORDER BY SUM(bc.item_quantity) DESC) r1,
    RANK() OVER (PARTITION BY MONTH(bc.bill_date) ORDER BY SUM(bc.item_quantity) ASC) r2
  FROM booking_commercials bc
  WHERE YEAR(bc.bill_date) = 2021
  GROUP BY MONTH(bc.bill_date), bc.item_id
)
SELECT * FROM item_counts
WHERE r1 = 1 OR r2 = 1;
[9:31 PM, 4/8/2026] ✨Dhanush ❤️‍🔥: WITH bill_rank AS (
  SELECT 
    MONTH(bc.bill_date) AS month,
    bc.bill_id,
    SUM(bc.item_quantity * i.item_rate) AS total_amount,
    RANK() OVER (PARTITION BY MONTH(bc.bill_date) ORDER BY SUM(bc.item_quantity * i.item_rate) DESC) rnk
  FROM booking_commercials bc
  JOIN items i ON bc.item_id = i.item_id
  WHERE YEAR(bc.bill_date) = 2021
  GROUP BY MONTH(bc.bill_date), bc.bill_id
)
SELECT * FROM bill_rank WHERE rnk = 2;